<?php $__env->startSection('content'); ?>
<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-body">
                    <?php if($room->foto): ?>
                        <img src="<?php echo e(asset('storage/' . $room->foto)); ?>" class="img-fluid mb-3" alt="<?php echo e($room->nama_ruangan); ?>">
                    <?php endif; ?>
                    <h2><?php echo e($room->nama_ruangan); ?></h2>
                    <p class="text-muted"><?php echo e($room->category->nama_kategori); ?></p>
                    <hr>
                    <dl class="row">
                        <dt class="col-sm-3">Kapasitas</dt>
                        <dd class="col-sm-9"><?php echo e($room->kapasitas); ?> orang</dd>
                        <dt class="col-sm-3">Deskripsi</dt>
                        <dd class="col-sm-9"><?php echo e($room->deskripsi ?? '-'); ?></dd>
                        <dt class="col-sm-3">Fasilitas</dt>
                        <dd class="col-sm-9"><?php echo e($room->fasilitas ?? '-'); ?></dd>
                    </dl>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('guest.rooms.booking', $room)); ?>" class="btn btn-primary">Booking Ruangan</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Login untuk Booking</a>
                    <?php endif; ?>
                </div>
            </div>

            <?php if($upcomingBookings->count() > 0): ?>
            <div class="card shadow mt-4">
                <div class="card-header">
                    <h3 class="mb-0">Jadwal Terjadwal</h3>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        <?php $__currentLoopData = $upcomingBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1"><?php echo e($booking->tanggal->format('d/m/Y')); ?></h5>
                                <small><?php echo e($booking->jam_mulai); ?> - <?php echo e($booking->jam_selesai); ?></small>
                            </div>
                            <p class="mb-1"><?php echo e($booking->keperluan ?? '-'); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-header">
                    <h3 class="mb-0">Informasi</h3>
                </div>
                <div class="card-body">
                    <p><strong>Status:</strong> 
                        <?php if($room->status == 'tersedia'): ?>
                            <span class="badge badge-success">Tersedia</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Tidak Tersedia</span>
                        <?php endif; ?>
                    </p>
                    <a href="<?php echo e(route('guest.rooms.index')); ?>" class="btn btn-secondary btn-block">Kembali ke Daftar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon-6.0-minimal\www\ProjectBokingRuangan\resources\views/guest/rooms/show.blade.php ENDPATH**/ ?>