<?php $__env->startSection('content'); ?>
<div class="container-fluid mt--7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header border-0">
                    <h3 class="mb-0">Booking Saya</h3>
                </div>
                <div class="card-body">
                    <!-- Filter Form -->
                    <form method="GET" action="<?php echo e(route('guest.bookings.index')); ?>" class="mb-4">
                        <div class="row">
                            <div class="col-md-4">
                                <select name="status" class="form-control">
                                    <option value="">Semua Status</option>
                                    <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                    <option value="approved" <?php echo e(request('status') == 'approved' ? 'selected' : ''); ?>>Approved</option>
                                    <option value="rejected" <?php echo e(request('status') == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" class="btn btn-primary">Filter</button>
                                <a href="<?php echo e(route('guest.bookings.index')); ?>" class="btn btn-secondary">Reset</a>
                            </div>
                        </div>
                    </form>

                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($booking->room->nama_ruangan); ?></h5>
                                    <p class="card-text">
                                        <strong>Tanggal:</strong> <?php echo e($booking->tanggal->format('d/m/Y')); ?><br>
                                        <strong>Jam:</strong> <?php echo e($booking->jam_mulai); ?> - <?php echo e($booking->jam_selesai); ?><br>
                                        <strong>Status:</strong> 
                                        <?php if($booking->status == 'pending'): ?>
                                            <span class="badge badge-warning">Pending</span>
                                        <?php elseif($booking->status == 'approved'): ?>
                                            <span class="badge badge-success">Approved</span>
                                        <?php elseif($booking->status == 'rejected'): ?>
                                            <span class="badge badge-danger">Rejected</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12">
                            <div class="alert alert-info">
                                Anda belum memiliki booking.
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="mt-4">
                        <?php echo e($bookings->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon-6.0-minimal\www\ProjectBokingRuangan\resources\views/guest/bookings/index.blade.php ENDPATH**/ ?>