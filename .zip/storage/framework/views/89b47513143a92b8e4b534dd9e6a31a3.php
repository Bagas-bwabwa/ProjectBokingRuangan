<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0">Daftar Ruangan Tersedia</h3>
                    </div>
                    <?php if(auth()->guard()->check()): ?>
                    <div class="col-auto">
                        <a href="<?php echo e(route('guest.dashboard')); ?>" class="btn btn-sm btn-primary">Dashboard Saya</a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                    <!-- Search & Filter Form -->
                    <form method="GET" action="<?php echo e(route('guest.rooms.index')); ?>" class="mb-4">
                        <div class="row">
                            <div class="col-md-4">
                                <input type="text" name="search" class="form-control" placeholder="Cari ruangan..." value="<?php echo e(request('search')); ?>">
                            </div>
                            <div class="col-md-3">
                                <select name="category_id" class="form-control">
                                    <option value="">Semua Kategori</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php echo e(request('category_id') == $category->id ? 'selected' : ''); ?>><?php echo e($category->nama_kategori); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <input type="number" name="kapasitas" class="form-control" placeholder="Min. Kapasitas" value="<?php echo e(request('kapasitas')); ?>" min="1">
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary btn-block">Cari</button>
                            </div>
                        </div>
                    </form>

                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <?php if($room->foto): ?>
                                    <img src="<?php echo e(asset('storage/' . $room->foto)); ?>" class="card-img-top" alt="<?php echo e($room->nama_ruangan); ?>" style="height: 200px; object-fit: cover;">
                                <?php endif; ?>
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($room->nama_ruangan); ?></h5>
                                    <p class="card-text">
                                        <small class="text-muted"><?php echo e($room->category->nama_kategori); ?></small><br>
                                        <i class="ni ni-single-02"></i> Kapasitas: <?php echo e($room->kapasitas); ?> orang<br>
                                        <?php if($room->deskripsi): ?>
                                            <?php echo e(Str::limit($room->deskripsi, 100)); ?>

                                        <?php endif; ?>
                                    </p>
                                    <a href="<?php echo e(route('guest.rooms.show', $room)); ?>" class="btn btn-primary">Lihat Detail</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12">
                            <div class="alert alert-info">
                                Tidak ada ruangan yang tersedia.
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="mt-4">
                        <?php echo e($rooms->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon-6.0-minimal\www\ProjectBokingRuangan\resources\views/guest/rooms/index.blade.php ENDPATH**/ ?>