<footer class="py-5">
    <div class="container">
        <?php echo $__env->make('layouts.footers.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</footer><?php /**PATH C:\laragon-6.0-minimal\www\ProjectBokingRuangan\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>