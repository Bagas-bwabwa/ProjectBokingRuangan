<?php if(auth()->guard()->check()): ?>
    <?php echo $__env->make('layouts.navbars.navs.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>
    
<?php if(auth()->guard()->guest()): ?>
    <?php echo $__env->make('layouts.navbars.navs.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?><?php /**PATH C:\laragon-6.0-minimal\www\ProjectBokingRuangan\resources\views/layouts/navbars/navbar.blade.php ENDPATH**/ ?>