<svg xmlns="http://www.w3.org/2000/svg" width="8" height="12" viewBox="0 0 8 12" fill="none" <?php echo e($attributes); ?>>
  <g clip-path="url(#clip0_14550_6168)">
    <path d="M6.75 11.0001L4 8.25012L1.25 11.0001" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M6.75 1.50012L4 4.25012L1.25 1.50012" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
  </g>
  <defs>
    <clipPath id="clip0_14550_6168">
      <rect width="8" height="11" fill="white" style="fill:white;fill-opacity:1;" transform="translate(0 0.500122)"/>
    </clipPath>
  </defs>
</svg>
<?php /**PATH C:\laragon-6.0-minimal\www\ProjectBokingRuangan\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/icons/chevrons-down-up.blade.php ENDPATH**/ ?>